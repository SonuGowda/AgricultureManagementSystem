A Pen created at CodePen.io. You can find this one at http://codepen.io/kazzkiq/pen/pvqvxO.

 A fully responsive menu **without any need of JavaScript** and using less than 200 lines of functional CSS code.