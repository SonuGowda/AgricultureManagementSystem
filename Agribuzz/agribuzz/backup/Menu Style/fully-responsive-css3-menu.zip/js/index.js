/* No JS ;)
 *
 * Icons from entypo.com
 * Avatar from uifaces.com
 */