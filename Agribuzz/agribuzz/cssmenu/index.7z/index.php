<!DOCTYPE html>
<html >
 
 <head>
   
 <meta charset="UTF-8">
    
<title>CSS3 MENU BUILD</title>
    
    
    
    
   
     <link rel="stylesheet" href="css/style.css">

    
    
   
 
  </head>

  
<body>

        
<ul>
       
 <li class="active" style="width: 16.6666666666667%">
<a href="home.html"
        target="">Home</a></li>

      
  <li style="width: 16.6666666666667%"><a href="2.html" target="">2</a></li>

     
   <li style="width: 16.6666666666667%"><a href="3.html" target="">3</a></li>

     
  <li style="width: 16.6666666666667%"><a href="4.html" target="">4</a></li>

        
<li style="width: 16.6666666666667%"><a href="5.html" target="">5</a></li>

        
<li style="width: 16.6666666666667%"><a href="6.html" target="">6</a></li>
    </ul>
    
    
    
    
 
   
  </body>
</html>
